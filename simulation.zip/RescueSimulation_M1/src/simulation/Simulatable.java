package simulation;

public interface Simulatable {
	//containing the methods available for all Simulatable objects.
	
	
			//This method is resposnsible for performing the actions of each simulatable object 
			public void cycleStep();
			//TODO: Find where to implement the method carefully
}
