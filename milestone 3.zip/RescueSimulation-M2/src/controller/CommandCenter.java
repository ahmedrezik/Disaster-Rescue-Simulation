package controller;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.print.attribute.standard.MediaSize.Engineering;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;

import exceptions.UnitException;
import model.events.SOSListener;
import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;
import model.people.CitizenState;
import model.units.Unit;
import model.units.UnitState;
import simulation.Address;
import simulation.Rescuable;
import simulation.Simulator;
import view.GameDisplay;
public class CommandCenter implements SOSListener,ActionListener{

	private Simulator engine;
	private ArrayList<ResidentialBuilding> visibleBuildings;
	private ArrayList<Citizen> visibleCitizens;
    private GameDisplay gameDisplay;
    private int cycle;
	@SuppressWarnings("unused")
	private ArrayList<Unit> emergencyUnits;
	private ArrayList<JButton> emergencies;
	private boolean flag=false;
	private int r;
	private ArrayList<JButton> occupants;
	private int x;
	private int y;

	public CommandCenter() throws Exception {
		engine = new Simulator(this);
		visibleBuildings = new ArrayList<ResidentialBuilding>();
		visibleCitizens = new ArrayList<Citizen>();
		emergencyUnits = engine.getEmergencyUnits();
		gameDisplay=new GameDisplay();
		 for(int i=0;i<gameDisplay.getButtons().size();i++) {
	        	gameDisplay.getButtons().get(i).addActionListener(this);
	        }
		 emergencies=new ArrayList<JButton>();
	        gameDisplay.getNextCycle().addActionListener(this);
	        gameDisplay.getLabel().setText("Number of Casualties:" + engine.calculateCasualties());
	        
	        for(int j=0;j<this.emergencyUnits.size();j++) {
	        	JButton a=new JButton(j+"");
	        	this.emergencies.add(a);
	        	a.addActionListener(this);
	        	this.gameDisplay.getUnit().setLayout(new GridLayout());
	        	this.gameDisplay.getResponding().setLayout(new GridLayout());
	        	if(this.emergencyUnits.get(j).getState()==UnitState.IDLE)
	        	this.gameDisplay.getUnit().add(a, new FlowLayout());
	        	else this.gameDisplay.getResponding().add(a, new FlowLayout());
	        }
	        this.gameDisplay.getRespond().addActionListener(this);
	        occupants=new ArrayList<JButton>();
	}

	@Override
	public void receiveSOSCall(Rescuable r) {
		
		if (r instanceof ResidentialBuilding) {
			
			if (!visibleBuildings.contains(r))
				visibleBuildings.add((ResidentialBuilding) r);
			
		} else {
			
			if (!visibleCitizens.contains(r))
				visibleCitizens.add((Citizen) r);
		}

	}
	@SuppressWarnings("deprecation")
	@Override
	public void actionPerformed(ActionEvent e) {
		if(flag && (!(this.gameDisplay.getButtons().contains(e.getSource())) && !this.occupants.contains(e.getSource()))) {
			flag=false;
			JOptionPane pop = new JOptionPane();
			pop.showMessageDialog(null, "error", "alert", JOptionPane.ERROR_MESSAGE);
		}
//		if(e.getSource()==this.gameDisplay.getNextCycle()) {
//			JOptionPane pop = new JOptionPane();
//			pop.showMessageDialog(null, "error", "alert", JOptionPane.ERROR_MESSAGE);
			//pop.show(true);
//			
//		}
		if(e.getSource()== gameDisplay.getNextCycle()) {
			String y="";
			String x="";
			String z="";
			cycle++;
			//lazem n-handle da
			try {
				engine.nextCycle();
			} catch (Exception e1) {
				JOptionPane pop = new JOptionPane();
				pop.showMessageDialog(null, "error", "alert", JOptionPane.ERROR_MESSAGE);
			}
			//visiblebuildings fadya bs buildings feha 3 elements
			 gameDisplay.getLabel().setText("Number of Casualties" + engine.calculateCasualties());
			 for(int i=0;i<this.visibleBuildings.size();i++){
				 if(this.visibleBuildings.get(i).getDisaster().getStartCycle()==cycle) {
					y+="Disaster "+ this.visibleBuildings.get(i).getDisaster().toString()+"\n";
				 }
				 if(this.visibleBuildings.get(i).getStructuralIntegrity()==0) {
					 x+="The Building located in ("+this.visibleBuildings.get(i).getLocation().getX()+","+this.visibleBuildings.get(i).getLocation().getY()+") is destroyed ,and all the occupants are dead"+"\n";
				 }
				 if(this.visibleBuildings.get(i).getGasLevel()==100) {
					 x+="Gas Level in Building located in ("+this.visibleBuildings.get(i).getLocation().getX()+","+this.visibleBuildings.get(i).getLocation().getY()+") reached 100 ,and all the occupants are Dead";
				 }
			 }
			 for(int i=0;i<this.visibleCitizens.size();i++) {
				 if(this.visibleCitizens.get(i).getState()==CitizenState.DECEASED) {
					 z+="The Citizen with id "+this.visibleCitizens.get(i).getNationalID()+" Located in ("+this.visibleCitizens.get(i).getLocation().getX()+","+this.visibleCitizens.get(i).getLocation().getY()+") is Dead"+"\n";
				 }
			 }
			 gameDisplay.getactivity().setText( gameDisplay.getactivity().getText()+"cycle"+cycle+"\n"+y+"\n"+x+"\n"+z);
	         gameDisplay.getLabel().setText("number of casualities:"+this.engine.calculateCasualties());	
	        // System.out.println(engine.checkGameOver());
	         this.gameDisplay.getUnit().removeAll();
	         this.gameDisplay.getResponding().removeAll();
	         while(!emergencies.isEmpty())
	         this.emergencies.remove(0);
	         for(int j=0;j<this.emergencyUnits.size();j++) {
		        	JButton a=new JButton(j+"");
		        	this.emergencies.add(a);
		        	a.addActionListener(this);
		        	this.gameDisplay.getUnit().setLayout(new GridLayout());
		        	this.gameDisplay.getResponding().setLayout(new GridLayout());
		        	if(this.emergencyUnits.get(j).getState()==UnitState.IDLE)
		        	this.gameDisplay.getUnit().add(a, new FlowLayout());
		        	else this.gameDisplay.getResponding().add(a, new FlowLayout());
		        }
	         
	         //System.out.println(engine.checkGameOver());
	         if(engine.checkGameOver()) {
	 //msh 3arfa n3ml eh
	        	 JOptionPane pop = new JOptionPane();
	 			pop.showMessageDialog(null, "Game Over", "alert", JOptionPane.ERROR_MESSAGE);
 }
		}
		if(this.gameDisplay.getButtons().contains(e.getSource())) {
			this.gameDisplay.getSidePane().removeAll();
//System.out.println(this.gameDisplay.getButtons().get(this.gameDisplay.getButtons().indexOf(e.getSource())).getText().charAt(4));
			int x=	Integer.parseInt(this.gameDisplay.getButtons().get(this.gameDisplay.getButtons().indexOf(e.getSource())).getText().charAt(1)+"");
		int y=	Integer.parseInt(this.gameDisplay.getButtons().get(this.gameDisplay.getButtons().indexOf(e.getSource())).getText().charAt(4)+"");
		if(flag==false) {
		if(engine.getBuildingByLocation2(new Address(x,y))!=null) {
			this.gameDisplay.getTxt2().setText(engine.getBuildingByLocation2(new Address(x,y)).toString());
			for(int i=0;i<engine.getBuildingByLocation2(new Address(x,y)).getOccupants().size();i++) {
				this.gameDisplay.getTxt2().setText(this.gameDisplay.getTxt2().getText()+"\n"+"Occupant:"+(i+1)+"\n"+engine.getBuildingByLocation2(new Address(x,y)).getOccupants().get(i).toString()+"\n");
			}
		}else if(engine.getCitizenByLocation(new Address(x,y)).size()!=0) {
			for(int i=0;i<engine.getCitizenByLocation(new Address(x,y)).size();i++) {
				this.gameDisplay.getTxt2().setText(engine.getCitizenByLocation(new Address(x,y)).get(i).toString()+"\n");
			}
		}
		else this.gameDisplay.getTxt2().setText("no information available");
		this.gameDisplay.getSidePane().removeAll();
		this.gameDisplay.getSidePane().setLayout(new BorderLayout());
		this.gameDisplay.getSidePane().add(this.gameDisplay.getBack(),BorderLayout.NORTH);
		this.gameDisplay.getSidePane().add(this.gameDisplay.getTxt2());
		}
		else {
			if(engine.getBuildingByLocation2(new Address(x,y))!=null) {
				if(engine.getBuildingByLocation2(new Address(x,y)).getOccupants().size()==0) {	
						try {
							this.emergencyUnits.get(r).respond(engine.getBuildingByLocation2(new Address(x,y)));
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							System.out.println("lolylolyloly");
							JOptionPane pop = new JOptionPane();
							pop.showMessageDialog(null, "error", "alert", JOptionPane.ERROR_MESSAGE);
						} flag=false;
				}
				else {
					this.x=Integer.parseInt(this.gameDisplay.getButtons().get(this.gameDisplay.getButtons().indexOf(e.getSource())).getText().charAt(1)+"");
					this.y=Integer.parseInt(this.gameDisplay.getButtons().get(this.gameDisplay.getButtons().indexOf(e.getSource())).getText().charAt(4)+"");
					JButton d=new JButton("the Building");
					occupants.add(d);
					d.addActionListener(this);
					this.gameDisplay.getSidePane().add(d);
					for(int i=0;i<engine.getBuildingByLocation2(new Address(x,y)).getOccupants().size();i++){
						JButton z=new JButton("occupant:"+(i+1));
						z.addActionListener(this);
						occupants.add(z);
						this.gameDisplay.getSidePane().add(z);
					}
				}
			}else if(engine.getCitizenByLocation(new Address(x,y)).size()!=0) {
				for(int i=0;i<engine.getCitizenByLocation(new Address(x,y)).size();i++){
					JButton z=new JButton("Citizen:"+(i+1));
					z.addActionListener(this);
					occupants.add(z);
					this.gameDisplay.getSidePane().add(z);
				}
			}else {
				 JOptionPane pop = new JOptionPane();
		 			pop.showMessageDialog(null, "no target is in here", "alert", JOptionPane.ERROR_MESSAGE);
		 			this.gameDisplay.add(this.gameDisplay.getTxt2());
			//this.gameDisplay.getTxt2().setText("no target is in here");
		 			
			}
			
			//this.gameDisplay.getSidePane().add(this.gameDisplay.getTxt2());
			
		}
		}
		if(emergencies.contains(e.getSource())) {
			//this.gameDisplay.getTxt3().add(this.gameDisplay.getRespond(),new FlowLayout());
			 System.out.println(this.emergencies.indexOf(e.getSource())); 
			this.gameDisplay.getTxt3().setText(this.emergencyUnits.get(this.emergencies.indexOf(e.getSource())).toString());
		   
		    r=this.emergencies.indexOf(e.getSource());
		    this.gameDisplay.getSidePane().add(this.gameDisplay.getElzorar());
		    
		}
		if(e.getSource()==this.gameDisplay.getRespond()) {
			flag=true;
		}
		if(this.occupants.contains(e.getSource())) {
			if(occupants.get(this.occupants.indexOf(e.getSource())).getText().equals("the Building")) {
				try {
					emergencyUnits.get(r).respond(this.engine.getBuildingByLocation2(new Address(x,y)));
				} catch (Exception e1) {
					System.out.println(emergencyUnits.get(r).canTreat(this.engine.getBuildingByLocation2(new Address(x,y))));
					System.out.println("EKHRASSSSSS!");
					JOptionPane pop = new JOptionPane();
					pop.showMessageDialog(null, "error", "alert", JOptionPane.ERROR_MESSAGE);
				}	
			}else {
				this.engine.getBuildingByLocation2(new Address(x,y)).getOccupants().get(occupants.indexOf(e.getSource())-1);
				try {
					emergencyUnits.get(r).respond(this.engine.getBuildingByLocation2(new Address(x,y)).getOccupants().get(occupants.indexOf(e.getSource())-1));
				} catch (Exception e1) {
					System.out.println("blablabla");
					JOptionPane pop = new JOptionPane();
					pop.showMessageDialog(null, "error", "alert", JOptionPane.ERROR_MESSAGE);
				}	
			}
			 
			flag=false;
		}
		this.gameDisplay.validate();
		this.gameDisplay.repaint();
	
	}
	public static void main(String [] args) throws Exception {
				CommandCenter c=new CommandCenter();
				//c.gameDisplay.setVisible(true);
	}

}


