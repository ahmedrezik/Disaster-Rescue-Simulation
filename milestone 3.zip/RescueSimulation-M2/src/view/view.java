package view;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
public class view extends JFrame implements ActionListener{
	private JPanel frame;
	private JPanel side;
	private JButton Info;
	private JButton Units;
	private JScrollPane scroll;
	private JTextArea info;
	private JPanel IDLE;
	private JPanel Responding;
	private JPanel Treating;
	

	public view() {
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLayout(null);
		this.frame=new JPanel();
		this.getContentPane().add(this.frame);
		this.frame.setBounds(0, 0, 2000, 1000);
		this.frame.setBackground(Color.WHITE);
		this.side=new JPanel();
		this.Info=new JButton("Info");
		this.Info.addActionListener(this);
		this.Units=new JButton("Units");
		this.Units.addActionListener(this);
		this.side.setLayout(null);
		this.side.add(this.Info);
		this.Info.setBounds(10,10,97,30);
		this.side.add(this.Units);
		this.Units.setBounds(112,10,97,30);
		this.frame.setLayout(null);
		this.frame.add(this.side);
		this.side.setBounds(1700, 0, 300, 1000);
		this.side.setBackground(Color.ORANGE);
		this.info=new JTextArea();
		this.scroll=new JScrollPane(this.info);
		this.scroll.setLayout(new ScrollPaneLayout());
		this.side.add(this.scroll);
		this.scroll.setBounds(10, 50, 200, 950);
		this.IDLE=new JPanel();
		this.Responding=new JPanel();
		//msh 3arfa nhotaha wla eh
		this.Treating=new JPanel();
		this.repaint();
		this.validate();
		// TODO Auto-generated constructor stub
	}
    public static void main(String[] args) {
    	view x=new view();
    }
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==this.Info) {
			this.info.setFont(new Font(Font.SERIF,Font.PLAIN,18));
			this.info.setText("OHHHHHH YEAHHHH!");
		}
		if(e.getSource()==this.Units) {
			this.side.remove(this.scroll);
			this.repaint();
			this.validate();
			
		}
	}
}
